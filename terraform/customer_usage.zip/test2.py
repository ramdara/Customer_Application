import json
import boto3
from boto3.dynamodb.conditions import Key
from datetime import datetime
from collections import defaultdict

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Customer_usage')

def lambda_handler(event, context):
    method = event['httpMethod']
    path = event.get('resource', '')
    
    # CORS Preflight
    if method == 'OPTIONS':
        return cors_response(200, '')

    try:
        if method == 'POST' and path.endswith('/energy/input'):
            return handle_input(event)
        elif method == 'GET' and path.endswith('/energy/history'):
            return handle_history(event)
        elif method == 'GET' and path.endswith('/energy/summary'):
            return handle_summary(event)
        else:
            return cors_response(404, {'error': 'Unsupported path or method'})
    except Exception as e:
        print(f"Unhandled error: {str(e)}")
        return cors_response(500, {'error': str(e)})


def handle_input(event):
    body = json.loads(event['body'])

    required_fields = ['Date', 'Usage', 'customerId', 'customerId#Date']
    if not all(field in body for field in required_fields):
        return cors_response(400, {'error': 'Missing required fields in payload'})

    item = {
        'customerId': body['customerId'],
        'Date': body['Date'],
        'Usage': body['Usage'],
        'customerId#Date': body['customerId#Date'],
    }

    table.put_item(Item=item)
    return cors_response(200, {'message': 'Energy usage submitted successfully'})


def handle_history(event):
    query = event.get('queryStringParameters') or {}
    start_date = query.get('startDate')
    end_date = query.get('endDate')
    customer_id = query.get('customer_id')

    if not start_date or not end_date:
        return cors_response(400, {'error': 'Missing startDate or endDate'})

    # customer_id = get_customer_id_from_token(event)
    # print(customer_id)
    # if not customer_id:
    #     return cors_response(401, {'error': 'Unauthorized'})

    start_key = f"{customer_id}#{start_date}"
    end_key = f"{customer_id}#{end_date}"

    response = table.query(
        KeyConditionExpression=Key('customerId').eq(customer_id) & Key('customerId#Date').between(start_key, end_key)
    )

    results = [
        {'date': item['Date'], 'usage': item['Usage']}
        for item in response.get('Items', [])
    ]

    return cors_response(200, results)


def handle_summary(event):
    query = event.get('queryStringParameters') or {}
    period = query.get('period', 'daily')
    customer_id = query.get('customer_id')

    # customer_id = get_customer_id_from_token(event)
    # if not customer_id:
    #     return cors_response(401, {'error': 'Unauthorized'})

    response = table.query(
        KeyConditionExpression=Key('customerId').eq(customer_id)
    )

    items = response.get('Items', [])

    summary = defaultdict(float)

    for item in items:
        date_str = item['Date']
        usage = float(item['Usage'])
        dt = datetime.strptime(date_str, '%Y-%m-%d')

        if period == 'monthly':
            key = dt.strftime('%Y-%m')
        elif period == 'weekly':
            key = f"{dt.strftime('%Y')}-W{dt.isocalendar()[1]}"
        else:
            key = date_str

        summary[key] += usage

    result = [{'period': k, 'usage': v} for k, v in sorted(summary.items())]

    return cors_response(200, result)


# def get_customer_id_from_token(event):
#     # print(event.get('requestContext', {}))
#     return event.get('requestContext', {}).get('authorizer', {}).get('jwt', {}).get('claims', {}).get('email')


def cors_response(status_code, body):
    return {
        'statusCode': status_code,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'OPTIONS,GET,POST',
        },
        'body': json.dumps(body)
    }
